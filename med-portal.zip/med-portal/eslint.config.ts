import eslint from '@eslint/js';
import angular from 'angular-eslint';
import { defineConfig } from 'eslint/config';
import prettier from 'eslint-plugin-prettier/recommended';
import globals from 'globals';
import tseslint from 'typescript-eslint';

// For a detailed explanation, visit:
// https://github.com/angular-eslint/angular-eslint/blob/main/docs/CONFIGURING_FLAT_CONFIG.md

// jhipster-needle-eslint-add-import - JHipster will add additional import here

export default defineConfig(
  {
    languageOptions: {
      globals: {
        ...globals.node,
      },
    },
  },

  {
    ignores: [
      'node_modules/**',
      'src/main/docker/**',
      'src/main/webapp/404.html',
      'src/main/webapp/index.html',
      'src/main/webapp/swagger-ui/**',
      'src/main/webapp/content/**',
      'jest.conf.js',
      'webpack/**',
      'target/**',
      'build/**',
      'node/**',
      'dist/**',
      'postcss.config.js',
    ],
  },

  eslint.configs.recommended,

  {
    files: ['**/*.{js,cjs,mjs}'],
    rules: {
      'no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    },
  },

  {
    files: ['src/main/webapp/**/*.ts'],

    extends: [...tseslint.configs.strictTypeChecked, ...tseslint.configs.stylistic, ...angular.configs.tsRecommended],

    languageOptions: {
      globals: {
        ...globals.browser,
      },

      parserOptions: {
        project: ['./tsconfig.app.json', './tsconfig.spec.json'],
      },
    },

    processor: angular.processInlineTemplates,

    rules: {
      '@angular-eslint/component-selector': [
        'error',
        {
          type: 'element',
          prefix: 'jhi',
          style: 'kebab-case',
        },
      ],

      '@angular-eslint/directive-selector': [
        'error',
        {
          type: 'attribute',
          prefix: 'jhi',
          style: 'camelCase',
        },
      ],

      '@angular-eslint/relative-url-prefix': 'error',

      '@typescript-eslint/consistent-type-definitions': 'off',
      '@typescript-eslint/explicit-module-boundary-types': 'off',

      '@typescript-eslint/no-confusing-void-expression': 'off',
      '@typescript-eslint/no-empty-object-type': 'off',
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-extraneous-class': 'off',
      '@typescript-eslint/no-misused-spread': 'off',
      '@typescript-eslint/no-floating-promises': 'off',
      '@typescript-eslint/no-non-null-assertion': 'off',

      '@typescript-eslint/no-shadow': ['error'],

      '@typescript-eslint/no-unnecessary-type-arguments': 'off',
      '@typescript-eslint/no-unsafe-argument': 'off',
      '@typescript-eslint/no-unsafe-assignment': 'off',
      '@typescript-eslint/no-unsafe-call': 'off',
      '@typescript-eslint/no-unsafe-member-access': 'off',
      '@typescript-eslint/no-unused-vars': 'off',
      '@typescript-eslint/unbound-method': 'off',

      '@angular-eslint/prefer-standalone': 'off',
      '@angular-eslint/prefer-inject': 'off',

      '@typescript-eslint/no-deprecated': 'off',
      '@typescript-eslint/consistent-indexed-object-style': 'off',
      '@typescript-eslint/consistent-generic-constructors': 'off',
      '@typescript-eslint/unified-signatures': 'off',
      '@typescript-eslint/no-unnecessary-condition': 'off',

      '@typescript-eslint/prefer-nullish-coalescing': 'off',
      '@typescript-eslint/prefer-optional-chain': 'off',
      '@typescript-eslint/explicit-function-return-type': 'off',
      '@typescript-eslint/array-type': 'off',
      '@typescript-eslint/no-invalid-void-type': 'off',
      '@typescript-eslint/no-unsafe-return': 'off',

      eqeqeq: 'off',
      'no-useless-escape': 'off',

      '@typescript-eslint/no-redundant-type-constituents': 'off',
      '@typescript-eslint/no-unnecessary-type-conversion': 'off',
      '@typescript-eslint/restrict-template-expressions': 'off',
      '@typescript-eslint/member-ordering': 'off',
      '@typescript-eslint/await-thenable': 'off',
      '@typescript-eslint/use-unknown-in-catch-callback-variable': 'off',

      'arrow-body-style': 'error',
      curly: 'error',
      'guard-for-in': 'error',
      'no-bitwise': 'error',
      'no-caller': 'error',

      'no-console': [
        'error',
        {
          allow: ['warn', 'error'],
        },
      ],

      'no-eval': 'error',
      'no-labels': 'error',
      'no-new': 'error',
      'no-new-wrappers': 'error',

      'object-shorthand': [
        'error',
        'always',
        {
          avoidExplicitReturnArrows: true,
        },
      ],

      radix: 'error',
      'spaced-comment': ['warn', 'always'],
    },
  },

  {
    files: ['src/main/webapp/**/*.spec.ts'],

    rules: {
      '@typescript-eslint/no-empty-function': 'off',
    },
  },

  {
    // Hand-written ambient shims describing bpmn-js/diagram-js internals,
    // which ship no types of their own.
    files: ['src/main/webapp/app/bpmn-editor/types/**/*.d.ts'],

    rules: {
      '@typescript-eslint/no-unsafe-function-type': 'off',
      '@typescript-eslint/no-unnecessary-type-parameters': 'off',
    },
  },

  {
    // BPMN/diagram-js integration code inherited from upstream libraries.
    files: ['src/main/webapp/app/bpmn-editor/additional-modules/**/*.ts'],

    rules: {
      '@typescript-eslint/ban-ts-comment': 'off',
      '@typescript-eslint/no-shadow': 'off',
      '@typescript-eslint/no-unnecessary-type-parameters': 'off',
      '@typescript-eslint/no-unused-expressions': 'off',
      '@typescript-eslint/restrict-plus-operands': 'off',
    },
  },

  {
    files: ['src/main/webapp/**/*.html'],

    extends: [...angular.configs.templateRecommended, ...angular.configs.templateAccessibility],

    rules: {
      '@angular-eslint/template/click-events-have-key-events': 'off',
      '@angular-eslint/template/interactive-supports-focus': 'off',
      '@angular-eslint/template/prefer-control-flow': 'off',
      '@angular-eslint/template/eqeqeq': 'off',
      '@angular-eslint/template/label-has-associated-control': 'off',
      '@angular-eslint/template/alt-text': 'off',

      '@angular-eslint/no-empty-lifecycle-method': 'off',
    },
  },

  // jhipster-needle-eslint-add-config - JHipster will add additional config here

  {
    extends: [prettier],
  },
);

import { expect, test } from './support/medportal-fixtures';

/**
 * The BPMN editor is the one feature whose behaviour unit tests cannot reach: bpmn-js renders
 * through the SVG DOM, which jsdom does not implement, so its specs stub the modeler and cover
 * wiring only. These run against a real browser.
 *
 * The shared `page` fixture fails the test on any unexpected console error, page error or failed
 * request, so a moddle namespace that does not resolve or a renderer that throws surfaces here
 * rather than passing silently.
 */
test.describe('BPMN editor', () => {
  test('is behind the auth guard', async ({ page, mockApi }) => {
    await mockApi({ account: 'anonymous' });

    await page.goto('/bpmn-editor');

    await expect(page).toHaveURL(/\/login$/);
  });

  test('loads its lazy chunk and renders the bpmn-js canvas', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    await expect(page).toHaveURL(/\/bpmn-editor$/);
    await expect(page.locator('#designer-container')).toBeVisible();
    // bpmn-js builds this container and the SVG root itself; their presence means the modeler
    // constructed and attached without throwing.
    await expect(page.locator('.bpmn-canvas .bjs-container')).toBeVisible();
    await expect(page.locator('.bpmn-canvas .djs-container svg').first()).toBeVisible();
  });

  test('starts an empty diagram so the canvas has a root element', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // DesignerComponent seeds an empty diagram when no xml is supplied, and that diagram opens
    // with a start event — a process without one is not executable, and a blank canvas gives
    // the user nothing to drag from.
    await expect(page.locator('.bpmn-canvas .djs-element')).not.toHaveCount(0);
  });

  test('the Delete key removes an element once its label editor is closed', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // Placing an element opens its label editor and puts the caret inside it, so Delete belongs
    // to the text until Escape closes it. Worth pinning, because the sequence looks like the key
    // being unbound — it is not — and the shortcut dialog tells users about the Escape.
    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);

    const withTask = await page.locator('.bpmn-canvas .djs-element').count();
    await page.keyboard.press('Delete');
    await expect(page.locator('.bpmn-canvas .djs-element')).toHaveCount(withTask);

    await page.keyboard.press('Escape');
    await page.keyboard.press('Delete');

    await expect(page.locator('.bpmn-canvas .djs-element')).toHaveCount(withTask - 1);
  });

  test('offers Remove for the Start Event and keeps deletion undoable', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const startEvent = page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first();

    await expect(startEvent).toBeVisible();

    await startEvent.click();

    const remove = page.locator('.djs-context-pad .bpmn-icon-trash').last();

    await expect(remove).toBeVisible();
    await remove.click();

    await expect(startEvent).toHaveCount(0);

    await page.getByTestId('bpmnUndo').click();
    await expect(startEvent).toBeVisible();

    await page.getByTestId('bpmnRedo').click();
    await expect(startEvent).toHaveCount(0);
  });

  test('offers Remove for a newly created End Event and keyboard Delete follows the same rule', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const canvas = page.locator('.bpmn-canvas .djs-container');

    await expect(canvas).toBeVisible();

    const shapes = page.locator('.bpmn-canvas .djs-element.djs-shape[data-element-id]');

    const beforeIds = await shapes.evaluateAll(elements =>
      elements.map(element => element.getAttribute('data-element-id')).filter((id): id is string => Boolean(id)),
    );

    await page.locator('.djs-palette [data-action="create.end-event"]').click();

    const box = await canvas.boundingBox();

    expect(box).not.toBeNull();

    await page.mouse.click(box!.x + box!.width * 0.65, box!.y + box!.height * 0.35);

    // Close the direct-edit label editor while preserving the selection.
    await page.keyboard.press('Escape');

    let createdId = '';

    await expect
      .poll(async () => {
        const afterIds = await shapes.evaluateAll(elements =>
          elements.map(element => element.getAttribute('data-element-id')).filter((id): id is string => Boolean(id)),
        );

        const created = afterIds.filter(id => !beforeIds.includes(id));

        createdId = created[0] ?? '';

        return created.length;
      })
      .toBe(1);

    expect(createdId).not.toBe('');

    const endEvent = page.locator(`.bpmn-canvas .djs-element[data-element-id="${createdId}"]`);

    await expect(endEvent).toBeVisible();

    // Prove the newly created shape is actually an event.
    await expect(endEvent.locator('.djs-visual > circle').first()).toBeVisible();

    // bpmn-js already selects a freshly created shape. Do NOT click it again:
    // the HTML canvas container may legitimately intercept that synthetic click.
    await expect(endEvent).toHaveClass(/selected/);

    // Requirement #1: the Remove option must exist for End Event.
    const remove = page.locator('.djs-context-pad .bpmn-icon-trash').last();

    await expect(remove).toBeVisible();

    // Requirement #2: keyboard deletion must follow the same rule.
    await page.keyboard.press('Delete');

    await expect(endEvent).toHaveCount(0);

    // Requirement #3: command stack remains intact.
    await page.getByTestId('bpmnUndo').click();

    await expect(page.locator(`.bpmn-canvas .djs-element[data-element-id="${createdId}"]`)).toBeVisible();

    await page.getByTestId('bpmnRedo').click();

    await expect(page.locator(`.bpmn-canvas .djs-element[data-element-id="${createdId}"]`)).toHaveCount(0);
  });
  test('still deletes an ordinary element', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // Stock bpmn-js deletion must keep ordinary and custom shapes removable too.
    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);

    const withTask = await page.locator('.bpmn-canvas .djs-element').count();
    await page.locator('.djs-context-pad .bpmn-icon-trash').click();

    await expect(page.locator('.bpmn-canvas .djs-element')).toHaveCount(withTask - 1);
  });

  test('right-clicking an element offers the types it can become', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // The seeded start event is a replaceable element, so ContextMenuProvider hands it to the
    // stock bpmn-replace popup rather than to our create menu.
    const startEvent = page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first();
    await startEvent.click({ button: 'right' });

    await expect(page.locator('.djs-popup [data-id="replace-with-message-start"]')).toBeVisible();
    await expect(page.locator('.bpmn-context-menu')).toHaveCount(0);
  });

  test('right-clicking bare canvas offers elements to create', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // The canvas resolves to the Process, which has no type to swap — bpmn-replace is empty for
    // it, so this is the case our own menu exists to cover.
    await page
      .locator('.bpmn-canvas .djs-container svg')
      .first()
      .click({ button: 'right', position: { x: 420, y: 320 } });

    const menu = page.locator('.bpmn-context-menu');
    await expect(menu).toBeVisible();
    await expect(menu.locator('.context-menu_header')).toHaveText('Create Element');
    await expect(menu.locator('.context-menu_item')).not.toHaveCount(0);
  });

  test('picking from the create menu places that element', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');
    const before = await page.locator('.bpmn-canvas .djs-element').count();

    await page
      .locator('.bpmn-canvas .djs-container svg')
      .first()
      .click({ button: 'right', position: { x: 420, y: 320 } });

    // The chosen shape attaches to the cursor, exactly as dragging from the palette does, so a
    // second click is what commits it to the canvas.
    await page.locator('.bpmn-context-menu .context-menu_item', { hasText: 'Task' }).first().click();
    await page.locator('.bpmn-canvas .djs-container').click({ position: { x: 500, y: 380 } });

    await expect(page.locator('.bpmn-canvas .djs-element')).not.toHaveCount(before);
  });

  test('the create menu closes on a click elsewhere', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    await page
      .locator('.bpmn-canvas .djs-container svg')
      .first()
      .click({ button: 'right', position: { x: 420, y: 320 } });
    await expect(page.locator('.bpmn-context-menu')).toBeVisible();

    await page.locator('.bpmn-canvas').click({ position: { x: 200, y: 200 } });

    await expect(page.locator('.bpmn-context-menu')).toHaveCount(0);
  });

  test('renders the properties panel into the panel component', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // bpmn-js-properties-panel renders into the element PanelComponent registers.
    await expect(page.locator('.panel-content .bio-properties-panel')).toBeVisible();
  });

  test('the panel header is not laid out around an icon it never draws', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const header = page.locator('.panel > .panel-header');
    await expect(header).toHaveText('Properties');

    // `styles/panel.scss` carried the Vue `.panel-header` rule over whole: a grid whose first
    // 40px column held `common/BpmnIcon.vue`, with two rows beside it for the element name and
    // type. This header renders one word and no icon, so the title was squeezed into that column
    // and wrapped — "Proper" over "ties". Counting line boxes is what catches it; the text reads
    // the same either way, and a text assertion would pass over the top of it.
    const lineBoxes = await header.evaluate(el => {
      const range = document.createRange();
      range.selectNodeContents(el);
      return range.getClientRects().length;
    });
    expect(lineBoxes).toBe(1);
  });

  test('shows exactly the Vue palette tools in the Vue order', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const palette = page.locator('.bpmn-canvas .djs-palette');
    await expect(palette).toBeVisible();

    const expectedActions = [
      'hand-tool',
      'lasso-tool',
      'space-tool',
      'global-connect-tool',
      'create.start-event',
      'create.end-event',
      'create.merger-module',
      'create.fragmenter-module',
      'create.KafkaReceiver-module',
      'create.KafkaTransmitter-module',
      'create.HttpReceiver-module',
      'create.HttpTransmitter-module',
      'create.fileReceiver-module',
      'create.FileTransmitter-module',
      'create.dbReceiver-module',
      'create.dbTransmitter-module',
      'create.cdrParser-module',
      'create.csvTransformerCorner-module',
    ];

    const actualActions = await palette
      .locator('[data-action]')
      .evaluateAll(entries => entries.map(entry => entry.getAttribute('data-action')));

    expect(actualActions).toEqual(expectedActions);

    // These stock bpmn-js creation tools are intentionally not exposed in the
    // Vue-compatible top-level palette. The BPMN engine still supports them.
    for (const className of [
      'bpmn-icon-task',
      'bpmn-icon-gateway-none',
      'bpmn-icon-intermediate-event-none',
      'bpmn-icon-subprocess-expanded',
      'bpmn-icon-participant',
      'bpmn-icon-data-object',
      'bpmn-icon-data-store',
      'bpmn-icon-group',
    ]) {
      await expect(palette.locator(`.${className}`), `unexpected palette entry .${className}`).toHaveCount(0);
    }

    // Custom icon infrastructure stays installed for existing diagrams but
    // contributes no palette entry until an icon actually exists in the library.
    await expect(palette.locator('.custom-icon-entry')).toHaveCount(0);
  });
  test('places a custom module on the canvas', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const canvas = page.locator('.bpmn-canvas .djs-container');
    await expect(canvas).toBeVisible();
    const before = await page.locator('.bpmn-canvas .djs-element').count();

    // This is the end-to-end proof that the palette, the KafkaReceiver moddle extension, the
    // custom element factory and the renderer all agree: without any one of them this click
    // either throws on an unknown namespace or draws nothing.
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);

    await expect(page.locator('.bpmn-canvas .djs-element')).not.toHaveCount(before);
  });

  test('places a module at the size the custom element factory configures', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const canvas = page.locator('.bpmn-canvas .djs-container');
    await expect(canvas).toBeVisible();
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);
    await page.keyboard.press('Escape');

    // Every integration module extends bpmn:Task, and the Vue editor sized bpmn:Task 120x120
    // through `config.elementFactory`. Without that config CustomElementFactory has nothing to
    // read and bpmn-js's own 100x80 applies — which also draws the module's square corner icon
    // squashed, since the renderer stretches it to the shape's box.
    //
    // Read off the SVG so the assertion does not depend on the canvas zoom. moddle names the
    // shape after the nearest BPMN supertype it knows, so a placed KafkaReceiver is
    // `Activity_<id>` — the only Activity on a diagram that otherwise holds one start event.
    const shape = page.locator('.bpmn-canvas .djs-element[data-element-id^="Activity_"] .djs-visual > rect').first();
    await expect(shape).toHaveAttribute('width', '120');
    await expect(shape).toHaveAttribute('height', '120');
  });

  test('blocks saving while a module property is invalid, and says why', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // A FileTransmitter carries the IP field the Vue editor validated.
    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .fileTransmitter-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);
    await page.keyboard.press('Escape');

    const save = page.getByTestId('bpmnSave');
    await expect(save).toBeEnabled();

    // The panel renders each group collapsed; the fields exist but are not reachable until the
    // header is opened.
    await page.locator('.panel-content .bio-properties-panel-group-header', { hasText: 'FileTransmitter' }).click();

    const ip = page.locator('.panel-content [data-entry-id="ip"] input');
    await expect(ip).toBeVisible();
    await ip.fill('999.1.1.1');
    await ip.blur();

    // The panel says so on the field itself...
    await expect(page.locator('.panel-content [data-entry-id="ip"] .bio-properties-panel-error')).toHaveText(
      'Invalid IPv4 format (e.g., 192.168.1.1)',
    );
    // ...and the toolbar refuses to let it leave, naming the element and the reason. The Vue
    // Save button disabled itself with no explanation anywhere on the page.
    await expect(save).toBeDisabled();
    const problems = page.getByTestId('bpmnProblems');
    await expect(problems).toBeVisible();
    await expect(problems).toContainText('IP Address');
    await expect(problems).toContainText('Invalid IPv4 format');

    await ip.fill('10.0.0.1');
    await ip.blur();

    await expect(save).toBeEnabled();
    await expect(problems).toHaveCount(0);
  });

  test('leaves an unfilled property alone', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // None of the validated properties is required. A module dropped on the canvas and not yet
    // configured must not block the save.
    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .fileTransmitter-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);
    await page.keyboard.press('Escape');

    await page.locator('.panel-content .bio-properties-panel-group-header', { hasText: 'FileTransmitter' }).click();

    await expect(page.locator('.panel-content [data-entry-id="ip"] input')).toHaveValue('');
    await expect(page.getByTestId('bpmnSave')).toBeEnabled();
    await expect(page.getByTestId('bpmnProblems')).toHaveCount(0);
  });

  test('names the selected element by its concrete type', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // `bpmn-icons/getIconType.ts` in the Vue editor derived this name so the panel header could
    // show it. bpmn-js-properties-panel's `PanelHeaderProvider` computes the same name from the
    // same function, so what the port needed here was nothing — and this is the test that says
    // so, rather than an assumption in a comment.
    const header = page.locator('.bio-properties-panel-header');

    await page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first().click();
    await expect(header).toContainText(/start event/i);

    await page
      .locator('.bpmn-canvas .djs-container svg')
      .first()
      .click({ button: 'right', position: { x: 420, y: 320 } });

    const menu = page.locator('.bpmn-context-menu');
    await expect(menu).toBeVisible();
    await menu.getByRole('menuitem', { name: 'Exclusive Gateway', exact: true }).click();

    // ContextMenuComponent starts create.start(...) asynchronously.
    await page.waitForTimeout(100);
    await page.locator('.bpmn-canvas .djs-container').click({ position: { x: 500, y: 380 } });
    await page.keyboard.press('Escape');

    // Not "Gateway": the concrete type, which is what tells an exclusive gateway from a parallel
    // one in a diagram where both are drawn as diamonds.
    await expect(header).toContainText(/exclusive gateway/i);
  });

  test('draws a different header icon per element type', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // The other half of what `bpmn-icons/` existed for: 123 lines mapping a concrete type to an
    // icon. The panel ships the same map. Comparing the two rendered icons is what distinguishes
    // "the right icon" from "an icon" — a fallback would pass a mere presence check.
    const icon = page.locator('.bio-properties-panel-header-icon svg');

    await page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first().click();
    await expect(icon).toBeVisible();
    const startEventIcon = await icon.innerHTML();

    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);
    await page.keyboard.press('Escape');

    await expect(icon).toBeVisible();
    expect(await icon.innerHTML()).not.toBe(startEventIcon);
  });

  test('offers execution listeners on the element types that accept them', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // `config/bpmnEnums.ts` was one constant, `LISTENER_ALLOWED_TYPES`, with one consumer: the
    // Vue execution-listener editor. bpmn-js-properties-panel declares a constant of the same
    // name with the same six entries in the same order and gates its own Execution listeners
    // group on it, so this group appearing is that constant doing its job.
    const groups = page.locator('.bio-properties-panel-group-header-title');

    await page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first().click();
    await expect(groups.filter({ hasText: 'Execution listeners' })).toHaveCount(1);

    await page
      .locator('.bpmn-canvas .djs-container svg')
      .first()
      .click({ button: 'right', position: { x: 420, y: 320 } });

    const menu = page.locator('.bpmn-context-menu');
    await expect(menu).toBeVisible();
    await menu.getByRole('menuitem', { name: 'Exclusive Gateway', exact: true }).click();

    // ContextMenuComponent starts create.start(...) asynchronously.
    await page.waitForTimeout(100);
    await page.locator('.bpmn-canvas .djs-container').click({ position: { x: 500, y: 380 } });
    await page.keyboard.press('Escape');
    await expect(groups.filter({ hasText: 'Execution listeners' })).toHaveCount(1);

    // And on the process itself, reached by clicking bare canvas.
    await page
      .locator('.bpmn-canvas .djs-container svg')
      .first()
      .click({ position: { x: 700, y: 420 } });
    await expect(groups.filter({ hasText: 'Execution listeners' })).toHaveCount(1);
  });

  test('the panel groups open and close from their header', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // `common/CollapseTitle.vue` was the title row the Vue panel put inside a naive-ui collapse
    // item — the hand-rolled half of a collapsible section. @bpmn-io/properties-panel's own
    // `Group` is the whole thing: header, title, arrow and the open/closed state
    // (`dist/index.esm.js:923`). Asserting the entries appear and disappear is what separates
    // that from a header that only looks the part.
    await page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first().click();

    const general = page
      .locator('.bio-properties-panel-group')
      .filter({ has: page.locator('.bio-properties-panel-group-header-title', { hasText: 'General' }) })
      .first();
    const header = general.locator('.bio-properties-panel-group-header');
    const entries = general.locator('.bio-properties-panel-group-entries');

    // Groups open closed, so the first click has to be the one that reveals the fields.
    await expect(entries).toBeHidden();

    await header.click();
    await expect(entries).toBeVisible();
    await expect(entries.locator('#bio-properties-panel-id')).toBeVisible();

    await header.click();
    await expect(entries).toBeHidden();
  });

  test('each property row labels its own control', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // `common/EditItem.vue` was the Vue panel's label-and-slot row, and its label was a plain
    // `<div>` at a fixed pixel width — text near a control, associated with nothing. The panel's
    // entries render a real `<label for>` bound to the input, so clicking the label focuses the
    // field. That association is the behaviour worth holding: a `<div>` beside an input satisfies
    // any assertion about the label's text.
    await page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]').first().click();

    const general = page
      .locator('.bio-properties-panel-group')
      .filter({ has: page.locator('.bio-properties-panel-group-header-title', { hasText: 'General' }) })
      .first();
    await general.locator('.bio-properties-panel-group-header').click();

    const idLabel = general.locator('label.bio-properties-panel-label[for="bio-properties-panel-id"]');
    await expect(idLabel).toHaveText('ID');

    await idLabel.click();
    await expect(page.locator('#bio-properties-panel-id')).toBeFocused();
  });

  test('exposes the toolbar actions', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    for (const title of ['Save', 'Export', 'Import', 'Cancel', 'Undo', 'Redo', 'Restart', 'Zoom out', 'Zoom in', 'Preview as XML']) {
      await expect(page.locator(`.toolbar button[title="${title}"]`), `toolbar ${title}`).toBeVisible();
    }
  });

  test('draws an icon in every toolbar button', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // This project ships FontAwesome as SVG components and loads no webfont stylesheet, so the
    // `<i class="fas fa-save">` markup the toolbar used before drew nothing at all. Counting the
    // rendered SVGs is what tells the two apart — the buttons look fine either way in a DOM dump.
    const buttons = page.locator('.toolbar button');
    const iconButtons = page.locator('.toolbar button svg.svg-inline--fa');

    // Every button but the zoom percentage carries an icon.
    await expect(iconButtons).toHaveCount((await buttons.count()) - 1);
  });

  test('zooms the canvas and reports the scale', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const level = page.getByTestId('bpmnZoomFit');
    await expect(level).toHaveText('100%');

    await page.getByTestId('bpmnZoomIn').click();
    await expect(level).toHaveText('110%');

    // One assertion per click: two in a row are delivered faster than the canvas redraws, and
    // the second then lands on a button Angular is mid-render on and is lost.
    await page.getByTestId('bpmnZoomOut').click();
    await expect(level).toHaveText('100%');
    await page.getByTestId('bpmnZoomOut').click();
    await expect(level).toHaveText('90%');

    // Fit-to-viewport lands on an arbitrary scale, and the label has to follow a zoom the
    // buttons did not cause.
    await level.click();
    await expect(level).not.toHaveText('90%');
  });

  test('previews the XML the editor would save', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    await page.getByTestId('bpmnPreviewXml').click();

    const preview = page.getByTestId('bpmnXmlPreview');
    await expect(preview).toBeVisible();
    // The real serialisation, not a placeholder: the seeded start event has to be in it.
    await expect(preview).toContainText('<bpmn:startEvent');
    await expect(preview).toContainText('bpmn:definitions');

    await page.locator('.modal-footer .btn-secondary').click();
    await expect(preview).toHaveCount(0);
  });

  test('restarts onto a fresh diagram', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);
    await page.keyboard.press('Escape');
    const withTask = await page.locator('.bpmn-canvas .djs-element').count();

    await page.getByTestId('bpmnRestart').click();

    // Back to the seeded diagram: the start event and nothing else.
    await expect(page.locator('.bpmn-canvas .djs-element')).toHaveCount(withTask - 1);
    await expect(page.locator('.bpmn-canvas .djs-element[data-element-id^="StartEvent"]')).toHaveCount(1);
  });

  test('lists the keyboard shortcuts', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    await page.getByTestId('bpmnShortcuts').click();

    const dialog = page.locator('.modal-body.shortcut-keys');
    await expect(dialog).toBeVisible();
    await expect(dialog.locator('h5')).toHaveText(['Editing', 'Tools', 'View']);
    await expect(dialog.getByText('Delete selection')).toBeVisible();
  });

  test('opens and closes the minimap', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // The module is registered by the `miniMap` setting, and the stylesheet hides the minimap's
    // own toggle — so if this button did nothing there would be no way to see the minimap at all.
    // diagram-js-minimap marks the open state with `open` on its own container and starts closed.
    const minimap = page.locator('.djs-minimap');
    await expect(minimap).toHaveCount(1);
    await expect(minimap).not.toHaveClass(/\bopen\b/);

    await page.getByTestId('bpmnToggleMinimap').click();
    await expect(minimap).toHaveClass(/\bopen\b/);

    await page.getByTestId('bpmnToggleMinimap').click();
    await expect(minimap).not.toHaveClass(/\bopen\b/);
  });

  test('the replace menu is a list, not a row that runs off the screen', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    const canvas = page.locator('.bpmn-canvas .djs-container');
    await page.locator('.djs-palette .KafkaReceiver-module').click();
    const box = await canvas.boundingBox();
    await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 3);
    await page.keyboard.press('Escape');
    await page.locator('.bpmn-canvas .djs-element[data-element-id^="Activity"]').first().click();
    await page.locator('.djs-context-pad .bpmn-icon-screw-wrench').click();
    await expect(page.locator('.djs-popup')).toBeVisible();

    // `styles/palette.scss` carried a `.djs-popup-group { display: flex !important }` over from
    // the Vue editor. diagram-js draws this menu as a `<ul>` inside a 300px popup and scrolls it
    // vertically (`.djs-popup-results { max-height: 280px; overflow: auto }`); forcing the list
    // into a row laid the ten "Change element" entries out 1341px wide, so eight of them fell
    // outside the popup — three under `.djs-popup-backdrop`, where a click dismisses the menu
    // rather than choosing a type, and four off the side of a 1280px viewport.
    //
    // Counting columns is what catches it. Every entry is present and carries the right label in
    // either layout, so a presence or text assertion walks straight past a menu the user cannot
    // reach the bottom half of.
    const geometry = await page.evaluate(() => {
      const popup = document.querySelector('.djs-popup')!.getBoundingClientRect();
      const entries = Array.from(document.querySelectorAll('.djs-popup-body .entry'));
      return {
        entryCount: entries.length,
        columns: new Set(entries.map(entry => Math.round(entry.getBoundingClientRect().left))).size,
        spillingRight: entries.filter(entry => entry.getBoundingClientRect().right > popup.right + 1).length,
      };
    });

    expect(geometry.entryCount).toBeGreaterThan(1);
    expect(geometry.columns).toBe(1);
    expect(geometry.spillingRight).toBe(0);
  });

  test('the grid background is painted on the element this editor renders', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });

    await page.goto('/bpmn-editor');

    // `bg: 'grid-image'` is the shipped default (`config/index.ts:13`), and the container carries
    // the class for it. The rule that draws the grid was written for Vue's `<div class="designer">`
    // and this editor renders `<jhi-designer>`, so — like the `.panel-header` grid before it — it
    // matched nothing and the default background drew nothing at all.
    await expect(page.locator('#designer-container')).toHaveClass(/\bdesigner-with-bg\b/);

    const background = await page.evaluate(() => {
      const style = getComputedStyle(document.querySelector('jhi-designer')!);
      return { image: style.backgroundImage, repeat: style.backgroundRepeat, size: style.backgroundSize };
    });

    expect(background.image).toMatch(/^url\("data:image\/svg\+xml;base64,/);
    // The tile is 40px and has to repeat. `bpmn-editor.component.scss` asks for `contain` on the
    // same element, which would stretch one tile over the whole canvas; the `background`
    // shorthand is `!important`, so it resets the size and this pins that it still does.
    expect(background.repeat).toBe('repeat');
    expect(background.size).toBe('auto');
  });

  // Two viewports, because the bug scaled with neither: the editor asked for a full `100vh`
  // starting below the navbar, so it hung exactly one navbar past the bottom at every size.
  for (const viewport of [
    { width: 1280, height: 720 },
    { width: 500, height: 640 },
  ]) {
    test(`the editor ends at the bottom of a ${viewport.width}x${viewport.height} viewport`, async ({ page, mockApi }) => {
      await mockApi({ account: 'admin' });
      await page.setViewportSize(viewport);

      await page.goto('/bpmn-editor');
      await expect(page.locator('.bpmn-canvas .bjs-container')).toBeVisible();
      await expect(page.locator('jhi-panel')).toBeVisible();

      // Measured, not asserted-to-exist. Before the fix every element below was present, visible
      // and the right size — it was just drawn 47px lower than the screen goes, and
      // `body { overflow: hidden }` from `bpmn-editor/styles/index.scss` meant nothing could
      // scroll to it. Only the numbers show that.
      const layout = await page.evaluate(() => {
        const bottom = (selector: string) => document.querySelector(selector)!.getBoundingClientRect().bottom;
        return {
          viewportBottom: window.innerHeight,
          navbarBottom: document.querySelector('jhi-navbar .navbar')!.getBoundingClientRect().bottom,
          containerTop: document.querySelector('#designer-container')!.getBoundingClientRect().top,
          containerBottom: bottom('#designer-container'),
          canvasBottom: bottom('.bpmn-canvas'),
          panelBottom: bottom('jhi-panel'),
          documentScrollHeight: document.documentElement.scrollHeight,
          documentClientHeight: document.documentElement.clientHeight,
        };
      });

      // No overflow: the canvas and the properties panel both end on the bottom edge of the
      // screen, not below it.
      expect(layout.canvasBottom).toBeLessThanOrEqual(layout.viewportBottom);
      expect(layout.panelBottom).toBeLessThanOrEqual(layout.viewportBottom);
      expect(layout.containerBottom).toBeCloseTo(layout.viewportBottom, 0);
      expect(layout.canvasBottom).toBeCloseTo(layout.viewportBottom, 0);
      expect(layout.panelBottom).toBeCloseTo(layout.viewportBottom, 0);

      // No gap: it starts where the navbar stops, so the whole space below the navbar is editor.
      expect(layout.containerTop).toBeCloseTo(layout.navbarBottom, 0);

      // And the route itself does not grow a scrollbar it would need in order to be whole.
      expect(layout.documentScrollHeight).toBe(layout.documentClientHeight);
    });
  }

  // This application ships Persian (`config/language.constants.ts`), and `MainComponent`
  // writes `dir` on `<html>` from it (`main.component.ts:84-88`), so RTL is a direction real
  // users run the editor in rather than an edge case. The height fix above is direction-neutral
  // by construction — a column flex chain — but "by construction" is what this test replaces
  // with numbers.
  test('the editor keeps its geometry in RTL, and its dividers follow the flip', async ({ page, mockApi }) => {
    await mockApi({ account: 'admin' });
    // `i18n/fa.json` is served by the build: `webpack.custom.js` registers `fa` alongside `en` at
    // the `jhipster-needle-i18n-language-webpack` line, so `MergeJsonWebpackPlugin` merges the 28
    // files in `i18n/fa/` into the bundle the dev server hands back here. Nothing about Persian is
    // faked in this test — `mockApi` routes `/api/**` and `/management/**` only — so the language
    // switch below exercises the same loader, `onLangChange` subscription and
    // `updatePageDirection` call that a real user reaches.
    await page.setViewportSize({ width: 1280, height: 720 });

    await page.goto('/bpmn-editor');
    await expect(page.locator('.bpmn-canvas .bjs-container')).toBeVisible();
    await expect(page.locator('jhi-panel')).toBeVisible();

    // Switched through the navbar the way a user does, and switched here rather than before
    // navigating: `updatePageDirection` is only reached from the `onLangChange` subscription, and
    // on a fresh load `TranslationModule` calls `use(langKey)` before `MainComponent` subscribes,
    // so a reload lands back on `dir="ltr"`.
    await page.locator('#languagesnavBarDropdown').click();
    await page.locator('.dropdown-menu a.dropdown-item', { hasText: 'فارسی' }).click();
    await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');

    const rtl = await page.evaluate(() => {
      const rect = (selector: string) => document.querySelector(selector)!.getBoundingClientRect();
      const panel = document.querySelector('jhi-panel')!;
      return {
        // Read alongside the geometry, so these numbers cannot quietly be an LTR run.
        direction: getComputedStyle(document.documentElement).direction,
        viewportBottom: window.innerHeight,
        navbarBottom: rect('jhi-navbar .navbar').bottom,
        containerTop: rect('#designer-container').top,
        canvasBottom: rect('.bpmn-canvas').bottom,
        panelBottom: rect('jhi-panel').bottom,
        documentScrollHeight: document.documentElement.scrollHeight,
        documentClientHeight: document.documentElement.clientHeight,
        canvasLeft: rect('.bpmn-canvas').left,
        panelLeft: rect('jhi-panel').left,
        documentScrollWidth: document.documentElement.scrollWidth,
        documentClientWidth: document.documentElement.clientWidth,
        panelBorderLeft: getComputedStyle(panel).borderLeftWidth,
        panelBorderRight: getComputedStyle(panel).borderRightWidth,
      };
    });

    expect(rtl.direction).toBe('rtl');

    // Vertically identical to LTR: the fix holds in both directions.
    expect(rtl.containerTop).toBeCloseTo(rtl.navbarBottom, 0);
    expect(rtl.canvasBottom).toBeCloseTo(rtl.viewportBottom, 0);
    expect(rtl.panelBottom).toBeCloseTo(rtl.viewportBottom, 0);
    expect(rtl.documentScrollHeight).toBe(rtl.documentClientHeight);

    // Horizontally mirrored, and no wider than the screen: the properties panel moves to the
    // left of the canvas instead of its right.
    expect(rtl.panelLeft).toBe(0);
    expect(rtl.canvasLeft).toBeGreaterThan(rtl.panelLeft);
    expect(rtl.documentScrollWidth).toBe(rtl.documentClientWidth);

    // The 1px divider is the reason these are logical properties and not `border-left`. With a
    // physical border it stayed on the panel's left edge, which in RTL is the outside of the
    // window: the divider between panel and canvas vanished and a stray line appeared at the
    // edge of the screen. It has to face the canvas in whichever direction the panel sits.
    expect(rtl.panelBorderRight).toBe('1px');
    expect(rtl.panelBorderLeft).toBe('0px');
  });
});

import { Component, OnDestroy, Input, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject } from 'rxjs';
import BpmnModeler from 'bpmn-js/lib/Modeler';
import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule, CamundaPlatformPropertiesProviderModule } from 'bpmn-js-properties-panel';
import { BpmnEditorService } from '../../services/bpmn-editor.service';
import { additionalModulesFor, moddleExtensionsFor } from '../../additional-modules';
import { translationModuleFor } from '../../i18n/translate';
import { DEFAULT_ELEMENT_SIZES } from '../../additional-modules/ElementFactory';
import ModulePropertiesModule from '../../module-properties';
import { createNewDiagram } from '../../utils/empty-diagram';
import ContextMenuModule from '../../context-menu';
import { RoleModulesService } from '../../services/role-modules.service';
import { BpmnElementAccessService } from '../../services/bpmn-element-access.service';
import ElementAccessModule from '../../additional-modules/ElementAccess';

@Component({
  selector: 'jhi-designer',
  templateUrl: './designer.component.html',
  styleUrls: ['./designer.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class DesignerComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvas') canvas!: ElementRef;
  @Input() xml: string | undefined;
  @Output() xmlUpdate = new EventEmitter<string>();

  private bpmnModeler: BpmnModeler | null = null;
  private destroy$ = new Subject<void>();

  constructor(
    private bpmnEditorService: BpmnEditorService,
    private roleModulesService: RoleModulesService,
    private elementAccessService: BpmnElementAccessService,
  ) {}
  ngAfterViewInit(): void {
    // PanelComponent is a sibling, so its ngAfterViewInit runs after this one in the same
    // change-detection pass. Deferring by a macrotask lets it register its element first, so
    // the properties panel has a parent to render into.
    setTimeout(() => this.initModeler(), 0);
  }

  ngOnDestroy(): void {
    if (this.bpmnModeler) {
      this.bpmnModeler.destroy();
    }
    this.bpmnEditorService.setBpmnModeler(null);
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initModeler(): void {
    if (!this.canvas) {
      setTimeout(() => this.initModeler(), 100);
      return;
    }

    const panelParent = this.bpmnEditorService.getPropertiesPanelParent();
    const settings = this.bpmnEditorService.getEditorSettings();

    // The palette and renderer modules the settings select, plus the properties panel's own
    // modules when a parent element exists for it to render into.
    const modules: unknown[] = additionalModulesFor(settings);
    // Overrides diagram-js's own `translate`, so every library label the editor draws goes
    // through the selected language's bundle. Registered here rather than in
    // `additionalModulesFor` because it is not one of the modules the settings switch on and off
    // — it is always present, and the language is what changes.
    modules.push(translationModuleFor(settings?.language));
    if (panelParent) {
      modules.push(BpmnPropertiesPanelModule, BpmnPropertiesProviderModule);
      // The Camunda groups read camunda-prefixed properties, so they only belong when that is
      // the engine in force; the other engines register their own moddle instead.
      if ((settings?.processEngine ?? 'camunda') === 'camunda') {
        modules.push(CamundaPlatformPropertiesProviderModule);
      }
      // The integration modules the palette places carry their own properties; without this
      // group a KafkaReceiver or HttpReceiver can be drawn but never configured.
      modules.push(ModulePropertiesModule);
    }

    // Right-click: the stock replace menu for an element, our create menu for the canvas.
    // Registered unconditionally — the module reads `config.contextMenu` and steps aside when
    // the setting is off, so the browser's own menu is what appears.
    modules.push(ContextMenuModule, ElementAccessModule);

    try {
      this.bpmnModeler = new BpmnModeler({
        container: this.canvas.nativeElement,
        keyboard: {
          // ViewerOptions uses one type parameter for both `container` and `keyboard.bindTo`,
          // and `container` must be an Element. documentElement receives the same bubbled
          // key events `window` did.
          bindTo: document.documentElement,
        },
        // Defines the namespaces the custom palette builds shapes with, plus the one process
        // engine schema in force; without them elementFactory.createShape fails on the
        // integration-module types.
        moddleExtensions: moddleExtensionsFor(settings),
        additionalModules: modules,

        // Vue parity:
        // when the minimap feature is enabled, open it immediately on editor load.
        // diagram-js-minimap itself handles click/drag navigation inside the overview.
        minimap: {
          open: settings?.miniMap ?? true,
        },
        // Reaches ModulePropertiesProvider as `config.processEngine`. Module properties are
        // namespaced by the engine, so an HttpReceiver stores `camunda:agreementMode`.
        processEngine: settings?.processEngine ?? 'camunda',
        // Reaches CustomElementFactory as `config.elementFactory`, which is the only thing that
        // class reads. The Vue editor supplied it and this did not, so the ported factory
        // returned bpmn-js's own sizes for everything; see the constant for what that cost.
        // Unread when no custom palette or renderer is configured, because the factory is only
        // registered alongside them and the stock one ignores the option.
        elementFactory: DEFAULT_ELEMENT_SIZES,
        // Reaches ContextMenuProvider as `config.contextMenu`.
        contextMenu: {
          enabled: settings?.contextmenu ?? true,
          custom: settings?.customContextmenu ?? true,
        },
        // The panel modules read `propertiesPanel.parent`, so it is only set when a parent
        // exists — the editor can be configured without the custom panel.
        roleModulesService: this.roleModulesService,
        // Plain data only: bpmn-js/didi is framework-agnostic and should not receive Angular services.
        elementAccess: this.elementAccessService.currentConfig(),
        ...(panelParent ? { propertiesPanel: { parent: panelParent } } : {}),
      });

      this.bpmnEditorService.setBpmnModeler(this.bpmnModeler);

      if (this.xml) {
        this.loadXml(this.xml);
      } else {
        // Without a diagram there is no canvas root and no element to select, so the properties
        // panel would render empty and the palette would refuse to place anything.
        //
        // Not `modeler.createDiagram()`: that always names the process `Process_1`, discarding
        // the configured processId and processName the flow is keyed on.
        createNewDiagram(this.bpmnModeler, settings).catch((error: unknown) => {
          console.error('Could not create BPMN 2.0 diagram', error);
        });
      }

      // Listen for xml changes
      this.bpmnModeler.on('commandStack.changed', () => {
        this.updateXml();
      });
    } catch (error) {
      console.error('Failed to initialize BPMN Modeler:', error);
    }
  }

  private loadXml(xml: string): void {
    if (!this.bpmnModeler) return;

    try {
      const disallowed = this.elementAccessService.findDisallowedXmlElements(xml);
      if (disallowed.length > 0) {
        console.error(
          `Could not import BPMN 2.0 diagram: ${disallowed.length} element type(s) are not allowed for the active portal owner.`,
        );
        return;
      }
    } catch (error: unknown) {
      console.error('Could not import BPMN 2.0 diagram: invalid or unsafe XML', error);
      return;
    }

    this.bpmnModeler.importXML(xml).catch((error: unknown) => {
      console.error('Could not import BPMN 2.0 diagram', error);
    });
  }

  private updateXml(): void {
    if (!this.bpmnModeler) return;

    this.bpmnModeler.saveXML({ format: true }).then((result: any) => {
      this.xmlUpdate.emit(result.xml);
    });
  }
}

import { vi } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRouteSnapshot, ActivatedRoute, Router, convertToParamMap } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';

import { IInstance } from '../instance.model';
import { InstanceService } from '../service/instance.service';

import { InstanceRoutingResolveService } from './instance-routing-resolve.service';

describe('Instance routing resolve service', () => {
  let mockRouter: Router;
  let mockActivatedRouteSnapshot: ActivatedRouteSnapshot;
  let routingResolveService: InstanceRoutingResolveService;
  let service: InstanceService;
  let resultInstance: IInstance | null | undefined;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: convertToParamMap({}),
            },
          },
        },
      ],
    });
    mockRouter = TestBed.inject(Router);
    vi.spyOn(mockRouter, 'navigate').mockImplementation(() => Promise.resolve(true));
    mockActivatedRouteSnapshot = TestBed.inject(ActivatedRoute).snapshot;
    routingResolveService = TestBed.inject(InstanceRoutingResolveService);
    service = TestBed.inject(InstanceService);
    resultInstance = undefined;
  });

  describe('resolve', () => {
    it('should return IInstance returned by find', () => {
      // GIVEN
      service.find = vi.fn(id => of(new HttpResponse({ body: { id } })));
      mockActivatedRouteSnapshot.params = { id: 123 };

      // WHEN
      routingResolveService.resolve(mockActivatedRouteSnapshot).subscribe(result => {
        resultInstance = result;
      });

      // THEN
      expect(service.find).toBeCalledWith(123);
      expect(resultInstance).toEqual({ id: 123 });
    });

    it('should return null if id is not provided', () => {
      // GIVEN
      service.find = vi.fn();
      mockActivatedRouteSnapshot.params = {};

      // WHEN
      routingResolveService.resolve(mockActivatedRouteSnapshot).subscribe(result => {
        resultInstance = result;
      });

      // THEN
      expect(service.find).not.toBeCalled();
      expect(resultInstance).toEqual(null);
    });

    it('should route to 404 page if data not found in server', () => {
      // GIVEN
      vi.spyOn(service, 'find').mockReturnValue(of(new HttpResponse<IInstance>({ body: null })));
      mockActivatedRouteSnapshot.params = { id: 123 };

      // WHEN
      routingResolveService.resolve(mockActivatedRouteSnapshot).subscribe(result => {
        resultInstance = result;
      });

      // THEN
      expect(service.find).toBeCalledWith(123);
      expect(resultInstance).toEqual(undefined);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['404']);
    });
  });
});

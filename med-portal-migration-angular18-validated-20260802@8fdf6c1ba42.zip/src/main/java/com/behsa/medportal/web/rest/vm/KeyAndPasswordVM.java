package com.behsa.medportal.web.rest.vm;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * View Model object for storing the user's reset key and new password.
 */
public class KeyAndPasswordVM {

    @NotBlank
    @Size(min = 20, max = 20)
    @Pattern(regexp = "^[A-Za-z0-9]+$")
    private String key;

    @NotBlank
    @Size(min = ManagedUserVM.PASSWORD_MIN_LENGTH, max = ManagedUserVM.PASSWORD_MAX_LENGTH)
    @Pattern(regexp = ManagedUserVM.PASSWORD_PATTERN, message = ManagedUserVM.PASSWORD_PATTERN_MESSAGE)
    private String newPassword;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}
